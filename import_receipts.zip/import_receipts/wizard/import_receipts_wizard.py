from odoo import api, fields, models, _
from odoo.exceptions import UserError
import pandas as pd
from datetime import datetime
from odoo.tools import ustr
import xlrd


class ImportReceipts(models.TransientModel):
    _name = 'import.receipts.wizard'
    _description = 'Import Receipts to Inventory'

    file = fields.Binary(string='File', required=True)

    def import_receipts(self):
        df = pd.read_excel(self.file, sheet_name=0)

        # Check if the file has the correct columns
        if not all(x in df.columns for x in ['product', 'quantity', 'location']):
            raise UserError(_('The file must contain the following columns: product, quantity, location'))